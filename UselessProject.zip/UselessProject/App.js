import React from 'react';
import DiscoScreen from './Components/DiscoScreen'

export default class App extends React.Component {
  render() {
    return (
      <DiscoScreen/>
    )
  }
}
