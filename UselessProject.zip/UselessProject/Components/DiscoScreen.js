import React from 'react'

import {
  StyleSheet,
  View,
  Text,
  TouchableOpacity
} from 'react-native'

class DiscoScreen extends React.Component {

  constructor(props) {
    super(props);
    this.color = ""
    this.blue = 0
    this.red = 0
    this.green = 0
  }

  _randomColor(){
    this.blue = Math.floor(Math.random() * 256);
    this.green = Math.floor(Math.random() * 256);
    this.red = Math.floor(Math.random() * 256);
    this.color = 'rgb('+this.red+','+this.green+', '+this.blue+')';
  }

  render(){
    this._randomColor();
    return(
      <View style={{ flex:1, backgroundColor: 'rgb('+this.red+', '+this.green+', '+this.blue+')' }}>

        <TouchableOpacity style={{flex:1, justifyContent: 'center',alignItems: 'center'}} onPress={()=> {
          this.forceUpdate()
          }
        }>
          <Text style={{ fontWeight: 'bold',fontSize: 38 }}> HEY :D </Text>
        </TouchableOpacity>

      </View>
    )
  }

}

const styles = StyleSheet.create({
  main_container: {
    flex: 1
  }
})

export default DiscoScreen
